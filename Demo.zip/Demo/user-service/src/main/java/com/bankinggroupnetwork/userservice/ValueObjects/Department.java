package com.bankinggroupnetwork.userservice.ValueObjects;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class Department {

    private Long identification;
    private String Name;
    private String address;
    private String city;

}

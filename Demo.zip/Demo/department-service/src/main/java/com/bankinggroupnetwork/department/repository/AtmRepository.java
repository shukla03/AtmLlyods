package com.bankinggroupnetwork.department.repository;


import com.bankinggroupnetwork.department.entity.Atm;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;


@Repository
public interface AtmRepository extends JpaRepository<Atm,Long> {

    Atm findbyidentification(Long identification);

}
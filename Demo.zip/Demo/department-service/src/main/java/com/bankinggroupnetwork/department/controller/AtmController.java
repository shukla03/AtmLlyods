package com.bankinggroupnetwork.department.controller;

import com.bankinggroupnetwork.department.entity.Atm;
import com.bankinggroupnetwork.department.service.AtmService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/atms")
@Slf4j
public class AtmController {

    @Autowired
    private AtmService atmService;

    public AtmController(AtmService atmService) {
        this.atmService = atmService;
    }

    @PostMapping("/atm")
    public Atm saveAtm (Atm atm ){
        log.info("Inside saveAtm method of AtmController");
        return atmService.saveAtm(atm);
    }

 @GetMapping("/{id}")
    public Atm findbyidentification( @PathVariable("id") Long identification){
        log.info("Inside saveAtm method of AtmController");
        return atmService.findbyidentification(identification);
    }
}

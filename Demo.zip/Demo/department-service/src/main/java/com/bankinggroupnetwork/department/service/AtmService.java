package com.bankinggroupnetwork.department.service;

import com.bankinggroupnetwork.department.entity.Atm;
import com.bankinggroupnetwork.department.repository.AtmRepository;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
@Slf4j
public class AtmService {

    @Autowired
    private static AtmRepository atmRepository;

   public  Atm findbyidentification(Long identification) {
        log.info("Inside findbyId of AtmController");
        return atmRepository.findbyidentification(identification);
    }

    public  Atm saveAtm (Atm atm) {
        log.info("Inside saveAtm of AtmController");
        return atmRepository.save(atm);
    }
}
